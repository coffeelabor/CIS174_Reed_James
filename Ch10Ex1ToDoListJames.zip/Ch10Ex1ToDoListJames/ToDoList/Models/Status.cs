﻿namespace ToDoList.Models
{
    public class Status
    {
        public string StatusId { get; set; }
        public string Name { get; set; }
    }
}
